Given three integers (X, Y, and Z) representing the three sides of a triangle, identify whether the triangle is scalene, isosceles, or equilateral.

- If all three sides are equal, output EQUILATERAL.
- Otherwise, if any two sides are equal, output ISOSCELES.
- Otherwise, output SCALENE.


* Sample Input 1:
```
2
3
4
```

* Sample Output 1:
`SCALENE`

* Sample Input 2:
```
6
6
6
```

* Sample Output 2:
`EQUILATERAL`

## Note
- Create a file called `solution.sh` and save your solution in it.
