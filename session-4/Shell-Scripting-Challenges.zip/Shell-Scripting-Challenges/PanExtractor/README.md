# PanExtractor

In Linux, you will find yourself dealing with lots of different types of compression. To make it easir for yourself, create a shell script called `PanExtractor` the takes a compressed file as an input, checks its compression and decompress it.

- Files to decompress are provided in the directory.

# Note:
- Create a file called `solution.sh` and save your solution in it.
- You might need to google how to extract some of the given files.
