# Is my Directory Empty?

Create a shell script that checks if a directory is empty or not. 
    - If **empty**, print "The specified directory is empty".
    - if **not empty**, print "The specified directory isn't empty".
    
## Note:
- Create a file called `solution.sh` and save your solution in it.
