# Can you Beat the Compression?

The file `super-compression.MazenForCompression` is so compressed that you won't be able to decompress it.

## Note:
- Create a file called `solution.sh` and save your solution in it.

